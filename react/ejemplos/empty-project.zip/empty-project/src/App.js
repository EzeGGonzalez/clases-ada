import React, { Component } from 'react';
import Form from './Form'
import Resultado from './Resultado'
import './App.css'

class App extends Component {
  render() {
    return (
      <div className="App">
        <Form />
        <Resultado />
      </div>
    );
  }
}

export default App;