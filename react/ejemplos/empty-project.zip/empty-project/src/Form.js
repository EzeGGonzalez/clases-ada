import React, { Component } from 'react';

class Form extends Component {
  render() {
    return (
      <div>
        <input />
        <select>
        </select>

        <button>Calcular peso</button>
      </div>
    );
  }
}

export default Form;