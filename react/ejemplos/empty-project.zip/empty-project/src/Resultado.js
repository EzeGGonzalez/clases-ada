import React, { Component } from 'react';

class Resultado extends Component {
  render() {
    return (
      <div>
        <p>Tu peso en  es: </p>
      </div>
    );
  }
}

export default Resultado;